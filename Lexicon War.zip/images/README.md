# Image Assets

Place your image files in this folder:

## Required Files:
- `logo-splash.png` - Logo image for the 3-second intro splash screen
- `save-icon.png` - 32x32 icon for the save indicator (bottom-right corner)

## Usage:
- Logo splash: Displayed on game start with cinema fade effects
- Save icon: Shown in bottom-right corner when localStorage updates
