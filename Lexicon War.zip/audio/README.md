# Audio Files Location

Place your audio files in the following folders:

## Sound Effects (SFX) - .wav format
Place all sound effect files in: `public/audio/sfx/`

Required files:
- `attack.wav` - Battle attack sound (player/pet normal attacks)
- `spell.wav` - Casting any spell/skill in battle
- `buttonclick.wav` - **Button click sound (plays on all UI button clicks)**
- `equip.wav` - Equip items in equipment system
- `unequip.wav` - Unequip items from equipment system
- `coinspending.wav` - Whenever spending coins (upgrades, forging, etc.)
- `Levelup.mp3` - Level up sound (when hero manually levels up)

## Background Music (BGM) - .mp3 format
Place background music file in: `public/audio/bgm/`

Required file:
- `main.mp3` - Single BGM track that plays continuously
  - **100% volume** in lobby/main menu
  - **50% volume** during battles
  - Loops automatically

## File Format
- **SFX**: `.wav` format (as provided)
- **BGM**: `.mp3` format (as provided)
- Files are automatically copied to `dist/` during build

## Level-Up VFX
Place level-up visual effects in: `public/vfx/`
- `levelup.gif` - Level up animation (overlayed on hero avatar when manually leveling up)

## Notes
- All files in `public/` folder are automatically copied to `dist/` during build
- Files are referenced as `/audio/sfx/filename.wav` or `/audio/bgm/main.mp3` or `/vfx/levelup.gif` in the code
- The AudioManager will preload critical sounds (attack, buttonclick, spell) on game start
- Other sounds (equip, unequip, coinspending, Levelup) are loaded on first use (lazy loading)
- BGM plays continuously with volume adjustment between lobby and battle phases
- Settings button allows users to toggle SFX and BGM on/off (preferences saved in localStorage)
